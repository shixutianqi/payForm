public interface PayWays {
    void pay();
}
