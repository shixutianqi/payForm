import java.util.Scanner;

public class CriditPayment implements PayWays{
    @Override
    public void pay() {
        Scanner sc=new Scanner(System.in);
        System.out.println("请输入想要支付的金额");
        double money = sc.nextDouble();
        System.out.println("通过信用卡支付了"+money+"元");

    }
}
