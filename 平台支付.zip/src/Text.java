import java.util.Scanner;

public class Text {
    public static void main(String[] args) {
        /**布置界面**/

        while (true) {
            System.out.println("--------------------------------------");
            System.out.println("请选择需要支付的支付方式：");
            System.out.println("1,支付平台支付");
            System.out.println("2,银行卡网银支付");
            System.out.println("3,信用卡快捷支付");

            Scanner sc=new Scanner(System.in);
            int choice=sc.nextInt();

            PayWays payment=null;                                      //创建用于多态的父类引用

            switch (choice){
                case 1:
                    payment=new PlatformPayment();                     //父类引用指向子类对象
                    payment.pay();

                    return;
                case 2:
                    payment=new CardPayment();                 //父类引用指向子类对象
                    payment.pay();
                    //break;
                    return;
                case 3:
                    payment=new CriditPayment();               //父类引用指向子类对象
                    payment.pay();
                    //break ;
                    return;
                default:
                    System.out.println("请选择正确的支付方式！");
                    break ;                                 //设置标签，再次选择支付方式
            }
        }
    }
}