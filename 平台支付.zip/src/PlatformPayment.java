import java.util.Scanner;

public class PlatformPayment implements PayWays {
    @Override
    public void pay(){
        Scanner sc=new Scanner(System.in);
        System.out.println("请输入想要支付的金额");
        double money = sc.nextDouble();
        System.out.println("通过平台支付支付了"+money+"元");

    };
}
